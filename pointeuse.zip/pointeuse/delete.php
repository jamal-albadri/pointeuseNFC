<?php

 require 'script/users.php';
 
 if(!isset($_GET['id'])){
     header("location:index.php");
     exit;
 }
 else{
     deleteUser($_GET['id']);
     header("location:index.php");
     exit;
 }