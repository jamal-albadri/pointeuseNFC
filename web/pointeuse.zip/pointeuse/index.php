<?php

session_start();

require './script/users.php';
require './script/flashmessage.php';

if(isset($_SESSION['admin'])){
    $users = getUsers();
}
else{
    header("location:login.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="../bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/dashboard.css" rel="stylesheet">
    </head>
    <body>
        <?php
        CreateNavBar();
        ?>
        <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="#">Vue d'ensemble <span class="sr-only">(current)</span></a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <div class="container">
            <h2 style="padding-top: 50px;">Collaborateurs</h2>
            <?php
            if (!empty($_SESSION['message'])) {
                ?>
                <div class="alert alert-success alert-dismissable" role="alert">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <h4 class="alert-heading">Succès</h4>
                    <p><?php echo GetFlashMessage(); ?></p>
                </div>
                <?php
            }
            ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Prénom</th>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Heure de début</th>
                        <th>Voir profil</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach ($users as $infos){
                    $idCollaborateur = $infos['idCollaborateur'];
                    $nom = $infos['nom'];
                    $prenom = $infos['prenom'];
                    $email = $infos['email'];
                    $heure = $infos['heureDebut'];
                    ?>
                    <tr>
                        <th><?php echo $idCollaborateur; ?></th>
                        <td><?php echo $nom; ?></td>
                        <td><?php echo $prenom; ?></td>
                        <td><?php echo $email; ?></td>
                        <td><?php echo $heure ?></td>
                        <td>    
                            <a href="edituser.php?id=<?php echo $idCollaborateur; ?>" class="btn btn-primary">
                                    <span class="glyphicon glyphicon-user" aria-hidden="true">
                                    </span>
                            </a>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
            <a href="addUser.php">
                <button type="button" class="btn btn-primary btn-lg">
                    Ajouter un utilisateur
                </button>
            </a>
        </div>
        </div>
      </div>
        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"
        integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
        <script src="../bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    </body>
</html>