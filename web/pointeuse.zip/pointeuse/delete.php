<?php

 require 'script/users.php';
 require 'script/flashmessage.php';
 
 if(!isset($_GET['id'])){
     header("location:index.php");
     exit;
 }
 else{
     deleteUser($_GET['id']);
     SetFlashMessage("Le collaborateur a bien été supprimé !");
     header("location:index.php");
     exit;
 }