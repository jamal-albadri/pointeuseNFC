<?php

function SetFlashMessage($message){
    $_SESSION['message'] = $message;
}

function GetFlashMessage(){
    $message = isset($_SESSION['message']) ? $_SESSION['message'] : "";
    $_SESSION['message'] = "";
    return $message;
}