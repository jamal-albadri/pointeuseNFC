<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once './script/flashmessage.php';
require_once './script/users.php';

$erreurs = array();

$nom = "";
$lundiMatin = "";
$lundiApresMidi = "";
$mardiMatin = "";
$mardiApresMidi = "";
$mercrediMatin = "";
$mercrediApresMidi = "";
$jeudiMatin = "";
$jeudiApresMidi = "";
$vendrediMatin = "";
$vendrediApresMidi = "";

if (filter_has_var(INPUT_POST, "submit")) {
    $nom = trim(filter_input(INPUT_POST, "Nom",FILTER_SANITIZE_STRING));
    $groupes = getGroups();
    foreach ($groupes as $value) {
        var_dump($value);
        var_dump($nom);
        if($nom == $value){
            $erreurs['nom'] = "Le groupe existe déjà";
            SetFlashMessage($erreurs['nom']);
        }
    }
    $lundiMatin = trim(filter_input(INPUT_POST, "LundiMatin", FILTER_SANITIZE_STRING));
    $lundiApresMidi = trim(filter_input(INPUT_POST, "LundiApresMidi", FILTER_SANITIZE_STRING));
    $mardiMatin = trim(filter_input(INPUT_POST, "MardiMatin", FILTER_SANITIZE_STRING));
    $mardiApresMidi = trim(filter_input(INPUT_POST, "MardiApresMidi", FILTER_SANITIZE_STRING));
    $mercrediMatin = trim(filter_input(INPUT_POST, "MercrediMatin", FILTER_SANITIZE_STRING));
    $mercrediApresMidi = filter_input(INPUT_POST, "MercrediApresMidi", FILTER_SANITIZE_STRING);
    $jeudiMatin = filter_input(INPUT_POST, "JeudiMatin", FILTER_SANITIZE_STRING);
    $jeudiApresMidi = filter_input(INPUT_POST, "JeudiApresMidi", FILTER_SANITIZE_STRING);
    $vendrediMatin = filter_input(INPUT_POST, "VendrediMatin", FILTER_SANITIZE_STRING);
    $vendrediApresMidi = filter_input(INPUT_POST, "VendrediApresMidi", FILTER_SANITIZE_STRING);
    
    if(empty($nom)){
        $erreurs['nom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['nom']);
    }
    else if(empty($lundiMatin)){
        $erreurs['lundiMatin'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['lundiMatin']);
    }
    else if(empty($lundiApresMidi)){
        $erreurs['lundiApresMidi'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['lundiApresMidi']);
    }
    else if(empty($mardiMatin)){
        $erreurs['mardiMatin'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['mardiMatin']);
    }
    else if(empty($mardiApresMidi)){
        $erreurs['mardiApresMidi'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['mardiApresMidi']);
    }
    else if(empty($mercrediMatin)){
        $erreurs['mercrediMatin'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['mercrediMatin']);
    }
    else if(empty($mercrediApresMidi)){
        $erreurs['mercrediApresMidi'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['mercrediApresMidi']);
    }
    else if(empty($jeudiMatin)){
        $erreurs['jeudiMatin'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['jeudiMatin']);
    }
    else if(empty($jeudiApresMidi)){
        $erreurs['jeudiApresMidi'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['jeudiApresMidi']);
    }
    else if(empty($vendrediMatin)){
        $erreurs['vendrediMatin'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['vendrediMatin']);
    }
    else if(empty($vendrediApresMidi)){
        $erreurs['vendrediApresMidi'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['vendrediApresMidi']);
    }
    if (empty($erreurs)) {
        SetFlashMessage("Le groupe a bien été créé");
        addGroup($nom);
        addHoraires($lundiMatin, $lundiApresMidi, $mardiMatin, $mardiApresMidi,
                $mercrediMatin, $mercrediApresMidi, $jeudiMatin, $jeudiApresMidi,
                $vendrediMatin, $vendrediApresMidi, returnLastId());
        header("location:index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="../bootstrap-3.3.7-dist/css/bootstrap.css" rel="stylesheet">
    </head>
    <body>
        <?php
        CreateNavBar();
        ?>
                <div class="container">
                    <h2 style="padding-top: 50px;">Créer un groupe</h2>
                    <form method="POST" action="">
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Nom du groupe :</label>
                            <div class="col-10">
                                <input class="form-control" type="text" value="<?php echo $nom ?>" name="Nom">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['nom'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage();?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Lundi matin :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $lundiMatin ?>" name="LundiMatin">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['lundiMatin'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage();?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Lundi après midi :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $lundiApresMidi ?>" name="LundiApresMidi">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['lundiApresMidi'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage(); ?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Mardi matin :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $mardiMatin ?>" name="MardiMatin">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['mardiMatin'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage();?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Mardi après midi :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $mardiApresMidi ?>" name="MardiApresMidi">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['mardiApresMidi'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage(); ?></p>
                            </div>
                            <?php
                        }
                        ?>                <div class="form-group row">
                            <label class="col-2 col-form-label">Mercredi matin :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $mercrediMatin ?>" name="MercrediMatin">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['mercrediMatin'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage();?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Mercredi après midi :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $mercrediApresMidi ?>" name="MercrediApresMidi">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['mercrediApresMidi'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage(); ?></p>
                            </div>
                            <?php
                        }
                        ?>                
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Jeudi matin :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $jeudiMatin ?>" name="JeudiMatin">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['jeudiMatin'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage();?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Jeudi après midi :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $jeudiApresMidi ?>" name="JeudiApresMidi">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['jeudiApresMidi'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage(); ?></p>
                            </div>
                            <?php
                        }
                        ?>                <div class="form-group row">
                            <label class="col-2 col-form-label">Vendredi matin :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $vendrediMatin ?>" name="VendrediMatin">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['vendrediMatin'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage();?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Vendredi après midi :</label>
                            <div class="col-10">
                                <input class="form-control" type="time" value="<?php echo $vendrediApresMidi ?>" name="VendrediApresMidi">
                            </div>
                        </div>
                        <?php
                        if (!empty($erreurs['vendrediApresMidi'])) {
                            ?>
                            <div class="alert alert-danger alert-dismissable" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <h4 class="alert-heading">Erreur</h4>
                                <p><?php echo GetFlashMessage(); ?></p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="form-group row">
                            <button type="submit" name="submit" class="btn btn-primary">Créer</button>
                        </div>
                    </form>
        </div>
        <script src="../bootstrap-3.3.7-dist/js/bootstrap.js"></script>
        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"
    integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="../bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    </body>
</html>