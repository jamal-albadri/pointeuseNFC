-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 10 jan. 2018 à 11:33
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `pointeuse`
--

-- --------------------------------------------------------

--
-- Structure de la table `collaborateurs`
--

CREATE TABLE `collaborateurs` (
  `idCollaborateur` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `motDePasse` varchar(100) NOT NULL,
  `estDedans` tinyint(1) NOT NULL,
  `estResponsable` tinyint(1) NOT NULL DEFAULT '0',
  `idGroupe` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `collaborateurs`
--

INSERT INTO `collaborateurs` (`idCollaborateur`, `nom`, `prenom`, `email`, `motDePasse`, `estDedans`, `estResponsable`, `idGroupe`) VALUES
(2, 'Gerard', 'Tiago', 'tiago.grrd@eduge.ch', '123456', 1, 1, 0),
(14, 'Gremaud', 'Denis', 'denis.grmd@eduge.ch', '123456', 0, 1, 0),
(12, 'Bovet', 'aïssa', 'aissa.bvt@eduge.ch', 'ca6d31399364c266e7b6b01e64743a6eed2ca73c8f386ccce930e93779962583', 0, 0, 0),
(16, 'test', 'test', 'test@test.com', '8a4b7678dc4cb89359bb4cf012bf967dd221e726c0204fa7c1fb8d262bcc6efe', 0, 0, 10),
(17, 'GerardZ', 'TiagoZ', 'tiagoz.grrd@eduge.ch', '8a4b7678dc4cb89359bb4cf012bf967dd221e726c0204fa7c1fb8d262bcc6efe', 0, 0, 10);

-- --------------------------------------------------------

--
-- Structure de la table `donnees`
--

CREATE TABLE `donnees` (
  `idDonnees` int(11) NOT NULL,
  `horodatage` datetime NOT NULL,
  `idCollaborateur` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `donnees`
--

INSERT INTO `donnees` (`idDonnees`, `horodatage`, `idCollaborateur`) VALUES
(1, '2017-12-06 00:00:00', 2),
(2, '2017-12-06 00:00:00', 2),
(3, '2017-12-27 00:00:00', 2),
(5, '2017-12-25 00:00:00', 2),
(6, '2017-12-06 00:00:00', 2);

-- --------------------------------------------------------

--
-- Structure de la table `groupes`
--

CREATE TABLE `groupes` (
  `idGroupe` int(11) NOT NULL,
  `nomGroupe` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `groupes`
--

INSERT INTO `groupes` (`idGroupe`, `nomGroupe`) VALUES
(10, 'I.FA-P3A');

-- --------------------------------------------------------

--
-- Structure de la table `horaires`
--

CREATE TABLE `horaires` (
  `idHoraire` int(11) NOT NULL,
  `lundiMatin` time NOT NULL,
  `lundiApresMidi` time NOT NULL,
  `mardiMatin` time NOT NULL,
  `mardiApresMidi` time NOT NULL,
  `mercrediMatin` time NOT NULL,
  `mercrediApresMidi` time NOT NULL,
  `jeudiMatin` time NOT NULL,
  `jeudiApresMidi` time NOT NULL,
  `vendrediMatin` time NOT NULL,
  `vendrediApresMidi` time NOT NULL,
  `idGroupe` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `horaires`
--

INSERT INTO `horaires` (`idHoraire`, `lundiMatin`, `lundiApresMidi`, `mardiMatin`, `mardiApresMidi`, `mercrediMatin`, `mercrediApresMidi`, `jeudiMatin`, `jeudiApresMidi`, `vendrediMatin`, `vendrediApresMidi`, `idGroupe`) VALUES
(3, '08:05:00', '12:40:00', '07:30:00', '12:40:00', '07:30:00', '12:40:00', '08:05:00', '12:40:00', '08:05:00', '12:40:00', 10);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `collaborateurs`
--
ALTER TABLE `collaborateurs`
  ADD PRIMARY KEY (`idCollaborateur`),
  ADD KEY `idGroupe` (`idGroupe`);

--
-- Index pour la table `donnees`
--
ALTER TABLE `donnees`
  ADD PRIMARY KEY (`idDonnees`),
  ADD KEY `idCollaborateur` (`idCollaborateur`);

--
-- Index pour la table `groupes`
--
ALTER TABLE `groupes`
  ADD PRIMARY KEY (`idGroupe`);

--
-- Index pour la table `horaires`
--
ALTER TABLE `horaires`
  ADD PRIMARY KEY (`idHoraire`),
  ADD KEY `idGroupe` (`idGroupe`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `collaborateurs`
--
ALTER TABLE `collaborateurs`
  MODIFY `idCollaborateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `donnees`
--
ALTER TABLE `donnees`
  MODIFY `idDonnees` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `groupes`
--
ALTER TABLE `groupes`
  MODIFY `idGroupe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `horaires`
--
ALTER TABLE `horaires`
  MODIFY `idHoraire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
