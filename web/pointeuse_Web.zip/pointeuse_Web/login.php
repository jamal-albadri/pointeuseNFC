<?php

session_start();

include 'script/users.php';
include 'script/flashmessage.php';

if (isset($_SESSION['admin'])) {
    header('location:index.php');
    exit;
}

if (isset($_REQUEST["inputEmail"]) && isset($_REQUEST["inputPassword"])) {
    $salt = hash("sha256","El#Grande\Salt");
    $pass = hash("sha256", $_REQUEST['inputPassword'] . $salt);
    $areYouOneOfUs = connect($_REQUEST["inputEmail"], $pass);
    if (isset($areYouOneOfUs[0])) {
        $infos = $areYouOneOfUs[0];
        $_SESSION['admin'] = $infos['estResponsable'];
        header('location:index.php');
        exit;
    } else {
        $erreurs = array();
        $erreurs['connexion'] = "Email ou mot de passe incorrect !";
        SetFlashMessage($erreurs['connexion']);
    }
}

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Entreprise - Login</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
  </head>

  <body>

    <div class="container">

    <form class="form-signin" method="POST" action="login.php">
        <h2 class="form-signin-heading">Connectez-vous</h2>
        <?php
        if(!empty($erreurs)){
            
        ?>
        <div class="alert alert-danger alert-dismissable" role="alert">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <h4 class="alert-heading">Erreur</h4>
            <p><?php echo GetFlashMessage();?></p>
        </div>
        <?php
        }
        ?>
        <input type="email" id="inputEmail" name="inputEmail" class="form-control" placeholder="Adresse email" required autofocus>
        <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Mot de passe" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Connexion</button>
    </form>

    </div> <!-- /container -->
  </body>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"
    integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="../bootstrap-3.3.7-dist/js/bootstrap.js"></script>
</html>
