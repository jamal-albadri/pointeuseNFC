<?php
DEFINE("DB_HOST","127.0.0.1");
DEFINE("DB_NAME","pointeuse");
DEFINE("DB_USER","root");
DEFINE("DB_PASS","");

function connectDb(){
    static $dbb=null;
    if($dbb==null){
        try{
        $connectionString="mysql:host=".DB_HOST.";dbname=".DB_NAME."";
        $dbb=new PDO($connectionString,DB_USER,DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
        $dbb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e){
            die('Erreur : '. $e->getMessage() );
        }
    }
    return $dbb;
}

function connect($email,$password){
    $connexion= connectDb();
    $request=$connexion->prepare("SELECT * FROM `collaborateurs` WHERE `email`=:email AND `motDePasse`=:password");
    $request->bindParam(':email',$email,PDO::PARAM_STR);
    $request->bindParam(':password',$password,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function disconnect(){
    session_start();
    $_SESSION = array();
    unset($_SESSION);
    session_destroy();
    header("location:../login.php");
    exit;
}


function gotInfos() {
    if (isset($_SESSION['email'])) {
        $infoUser = checkIfNotAlreadyInMail($_SESSION['email']);
        foreach ($infoUser as $value) {
            $_SESSION['idCollaborateur'] = $value['idCollaborateur'];
            $_SESSION['nom'] = $value['nom'];
            $_SESSION['prenom'] = $value['prenom'];
            $_SESSION['email'] = $value['email'];
            $_SESSION['heureDebut'] = $value['heureDebut'];
        }
    }
}

function checkIfNotAlreadyInMail($mail){
    $connexion= connectDb();
    $request=$connexion->prepare("SELECT * FROM `collaborateurs` WHERE `email`=:email");
    $request->bindParam(':email',$mail,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getPass($email){
    $connexion= connectDb();
    $request=$connexion->prepare("SELECT * FROM `collaborateurs` WHERE `email`=:email");
    $request->bindParam(':email',$email,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getUsers(){
    $connexion= connectDb();
    $request=$connexion->prepare("SELECT * FROM `collaborateurs`");
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getUser($idUser){
    $bdd = connectDb();
    $requete = $bdd->prepare("SELECT prenom,nom,email,estDedans,idGroupe FROM collaborateurs WHERE idCollaborateur = :idUser");
    $requete->bindParam(':idUser',$idUser,PDO::PARAM_STR);
    $requete->execute();
    $donnees = $requete->fetchAll(PDO::FETCH_ASSOC);
    return $donnees;
}

function deleteUser($idUser){
    $bdd = connectDb();
    $reponse = $bdd->query("DELETE FROM collaborateurs WHERE idCollaborateur = $idUser");
    return $reponse;
}

function addUser($nom, $prenom, $email, $pwd,$responsable,$idGroupe){
    $bdd = connectDb();
    $req = $bdd->prepare("INSERT INTO collaborateurs (nom,prenom,email,motDePasse,estDedans,estResponsable,idGroupe)"
            . " VALUES(:nom, :prenom, :email, :motDePasse, 0, :responsable,:idGroupe)");
    $req->bindParam(":nom", $nom,PDO::PARAM_STR);
    $req->bindParam(":prenom", $prenom,PDO::PARAM_STR);
    $req->bindParam(":email", $email,PDO::PARAM_STR);
    $req->bindParam(":motDePasse", $pwd,PDO::PARAM_STR);
    $req->bindParam(":responsable", $responsable,PDO::PARAM_INT);
    $req->bindParam(":idGroupe", $idGroupe,PDO::PARAM_INT);
    $req->execute();
    return $req;
}

function updateUser($prenom, $nom, $email, $pwd, $heureDebut,$idUser){
    $bdd = connectDb();
    $req = $bdd->prepare("UPDATE collaborateurs SET prenom = :prenom,"
            . " nom = :nom, email = :email, motDePasse = :motDePasse WHERE idCollaborateur=:idUser;");
    $req->bindParam(':idUser',$idUser,PDO::PARAM_STR);
    $req->bindParam(':prenom',$prenom,PDO::PARAM_STR);
    $req->bindParam(':nom',$nom,PDO::PARAM_STR);
    $req->bindParam(':email',$email,PDO::PARAM_STR);
    $req->bindParam(':motDePasse',$pwd,PDO::PARAM_STR);
    $req->bindParam(':heureDebut',$heureDebut,PDO::PARAM_STR);
    $req->execute();
    return $req;
}

function CreateNavBar(){
    echo '<nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">NomEntreprise</a>
              </div>
              <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="script/disconnect.php">Déconnexion</a></li>
                </ul>
              </div>
            </div>
        </nav>';
}

function getHoraires($idUser){
    $bdd = connectDb();
    $requete = $bdd->prepare("SELECT horodatage FROM donnees WHERE idCollaborateur = :idUser");
    $requete->bindParam(':idUser',$idUser,PDO::PARAM_STR);
    $requete->execute();
    $donnees = $requete->fetchAll(PDO::FETCH_ASSOC);
    return $donnees;
}

function addGroup($nomGroupe){
    $bdd = connectDb();
    $req = $bdd->prepare("INSERT INTO groupes (nomGroupe)"
            . " VALUES(:nomGroupe)");
    $req->bindParam(":nomGroupe", $nomGroupe, PDO::PARAM_STR);
    $req->execute();
    return $req;
}

function addHoraires($lundiMatin, $lundiApresMidi, $mardiMatin, $mardiApresMidi,
        $mercrediMatin, $mercrediApresMidi, $jeudiMatin, $jeudiApresMidi,
        $vendrediMatin, $vendrediApresMidi, $idGroupe){
    $bdd = connectDb();
    $req = $bdd->prepare("INSERT INTO horaires (lundiMatin, lundiApresMidi,"
            . " mardiMatin, mardiApresMidi, mercrediMatin, mercrediApresMidi,"
            . " jeudiMatin, jeudiApresMidi, vendrediMatin, vendrediApresMidi,"
            . " idGroupe) VALUES(:lundiMatin, :lundiApresMidi, :mardiMatin,"
            . " :mardiApresMidi, :mercrediMatin, :mercrediApresMidi,"
            . " :jeudiMatin, :jeudiApresMidi, :vendrediMatin,"
            . " :vendrediApresMidi, :idGroupe)");
    $req->bindParam(":lundiMatin", $lundiMatin, PDO::PARAM_STR);
    $req->bindParam(":lundiApresMidi", $lundiApresMidi, PDO::PARAM_STR);
    $req->bindParam(":mardiMatin", $mardiMatin, PDO::PARAM_STR);
    $req->bindParam(":mardiApresMidi", $mardiApresMidi, PDO::PARAM_STR);
    $req->bindParam(":mercrediMatin", $mercrediMatin, PDO::PARAM_STR);
    $req->bindParam(":mercrediApresMidi", $mercrediApresMidi, PDO::PARAM_STR);
    $req->bindParam(":jeudiMatin", $jeudiMatin, PDO::PARAM_STR);
    $req->bindParam(":jeudiApresMidi", $jeudiApresMidi, PDO::PARAM_STR);
    $req->bindParam(":vendrediMatin", $vendrediMatin, PDO::PARAM_STR);
    $req->bindParam(":vendrediApresMidi", $vendrediApresMidi, PDO::PARAM_STR);
    $req->bindParam(":idGroupe", $idGroupe, PDO::PARAM_INT);
    $req->execute();
    return $req;
}

function getGroups(){
    $bdd = connectDb();
    $requete = $bdd->prepare("SELECT * FROM groupes");
    $requete->execute();
    $donnees = $requete->fetchAll(PDO::FETCH_ASSOC);
    return $donnees;
}

function createListGroups(){
    $groups = getGroups();
    echo '<select class="form-control" name="groupe">';
    foreach ($groups as $value) {
        var_dump($value);
        echo '<option value="' . $value['idGroupe'] . '">' . $value['nomGroupe'] . '</option>';
    }
    echo '</select>';
}

/**
 * Fonction qui permet de récupérer le dernier id ajouter lors d'une requête insert
 * @return type
 */
function returnLastId(){
    $connexion= connectDb();
    $request=$connexion->prepare("SELECT LAST_INSERT_ID(idUtilisateur) FROM `tutilisateur`");
    return $connexion->lastInsertId();
}

function getHorairesMatinByGroupes($idGroupe){
    $bdd = connectDb();
    $requete = $bdd->prepare("SELECT lundiMatin, mardiMatin, mercrediMatin,"
            . " jeudiMatin, vendrediMatin FROM horaires WHERE idGroupe=:idGroupe");
    $requete->bindParam(':idGroupe',$idGroupe,PDO::PARAM_INT);
    $requete->execute();
    $donnees = $requete->fetchAll(PDO::FETCH_ASSOC);
    return $donnees;
}

function getHorairesApresMidiByGroupes($idGroupe){
    $bdd = connectDb();
    $requete = $bdd->prepare("SELECT lundiApresMidi, mardiApresMidi, mercrediApresMidi,"
            . " jeudiApresMidi, vendrediApresMidi FROM horaires WHERE idGroupe=:idGroupe");
    $requete->bindParam(':idGroupe',$idGroupe,PDO::PARAM_INT);
    $requete->execute();
    $donnees = $requete->fetchAll(PDO::FETCH_ASSOC);
    return $donnees;
}