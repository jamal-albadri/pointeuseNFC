<?php
require 'script/users.php';
require 'script/flashmessage.php';

$idUser = $_GET['id'] ? $_GET['id'] : null;
$infos = getUser($idUser);
$horaires = getHoraires($idUser);

foreach ($infos as $value) {
    $nom = $value['nom'];
    $prenom = $value['prenom'];
    $email = $value['email'];
    $estDedans = $value['estDedans'];
    $idGroupe = $value['idGroupe'];
}
$horairesMatin = getHorairesMatinByGroupes($idGroupe);
foreach ($horairesMatin as $value){
    $lundiMatin = $value['lundiMatin'];
    $mardiMatin = $value['mardiMatin'];
    $mercrediMatin = $value['mercrediMatin'];
    $jeudiMatin = $value['jeudiMatin'];
    $vendrediMatin = $value['vendrediMatin'];
}
$horairesApresMidi = getHorairesApresMidiByGroupes($idGroupe);
foreach ($horairesApresMidi as $value){
    $lundiApresMidi = $value['lundiApresMidi'];
    $mardiApresMidi = $value['mardiApresMidi'];
    $mercrediApresMidi = $value['mercrediApresMidi'];
    $jeudiApresMidi = $value['jeudiApresMidi'];
    $vendrediApresMidi = $value['vendrediApresMidi'];
}
$sortie = array();
$entree = array();
$cpt = 0;
foreach ($horaires as $value) {
    if($cpt % 2 == 0){
        array_push($entree,"<tr>" . "<td>" . $value['horodatage'] . "</td>");
    }
    else{
        array_push($sortie,"<td>" . $value['horodatage'] . "</td>" . "</tr>");
    }
    $cpt++;
}

if (filter_has_var(INPUT_POST, "submit")) {
    $prenom = trim(filter_input(INPUT_POST, "Prenom", FILTER_SANITIZE_STRING));
    $nom = trim(filter_input(INPUT_POST, "Nom", FILTER_SANITIZE_STRING));
    $email = trim(filter_input(INPUT_POST, "Email", FILTER_SANITIZE_STRING));
    $pwd = trim(filter_input(INPUT_POST, "Pwd", FILTER_SANITIZE_STRING));
    
    if(empty($nom)){
        $erreurs['nom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['nom']);
    }
    else if(empty($prenom)){
        $erreurs['prenom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['prenom']);
    }
    else if(empty($email)){
        $erreurs['email'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['email']);
    }
    else if(empty($pwd)){
        $erreurs['password'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['password']);
    }
    else if (empty($erreurs)) {
        $salt = hash("sha256","El#Grande\Salt");
        $pass = hash("sha256", $pwd . $salt);
        updateUser($prenom, $nom, $email, $pass, $idUser);
        SetFlashMessage("Le collaborateur $prenom a été modifié");
        header("location:index.php");
        exit;
    }
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="../bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="css/dashboard.css" rel="stylesheet">
    </head>
    <body>
        <?php
        CreateNavBar();
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-3 col-md-2 sidebar">
                  <ul class="nav nav-sidebar">
                        <li class=""><a href="index.php">Vue d'ensemble</a></li>
                        <li class="active"><a href="#"><?php echo "Collaborateur " . $prenom ?><span class="sr-only">(current)</span></a></li>
                        <li class=""><a href="addUser.php">Ajouter un collaborateur <span class="sr-only"></span></a></li>
                        <li class=""><a href="addGroup.php">Ajouter un groupe <span class="sr-only"></span></a></li>
                  </ul>
                </div>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2">
                <div class="container">
                    <div class="jumbotron">
                        <div class="row">
                          <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                              <img src="https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png" alt="stack photo" class="img">
                          </div>
                          <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
                              <div class="container" style="border-bottom:1px solid black">
                                  <h2><?php echo $prenom . " " . $nom; ?></h2>
                              </div>
                              <hr>
                                <ul class="container details">
                                    <li><p><span class="glyphicon glyphicon-envelope" style="width:50px;"></span><?php echo $email; ?></p></li>
                                    <?php
                                    if($estDedans){
                                        echo '<li><p class="estDedans"><span class="glyphicon glyphicon-map-marker" style="width:50px;"></span>est en classe</p></li>';
                                    }
                                    else{
                                        echo '<li><p class="estDehors"><span class="glyphicon glyphicon-map-marker" style="width:50px;"></span>n\'est pas en classe</p></li>';
                                    }
                                    ?>
                                </ul>
                            </div>
                            <button type="button" class="btn btn-primary btn-lg" data-href="#edit?id=<?php echo $_GET['id'];?>" data-toggle="modal" data-target="#edit">
                               <span class="glyphicon glyphicon-cog" style="width:50px;"></span>
                            </button>
                            <div id="edit" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Modification</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="editUser.php?id=<?php echo $idUser; ?>">
                                                <div class="form-group row">
                                                    <label class="col-2 col-form-label">Nom :</label>
                                                    <div class="col-10">
                                                        <input class="form-control" type="text" value="<?php echo $nom ?>" name="Nom">
                                                    </div>
                                                </div>
                                                <?php
                                                if (!empty($erreurs['nom'])) {
                                                    ?>
                                                    <div class="alert alert-danger alert-dismissable" role="alert">
                                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                        <h4 class="alert-heading">Erreur</h4>
                                                        <p><?php echo GetFlashMessage();?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="form-group row">
                                                    <label class="col-2 col-form-label">Prénom :</label>
                                                    <div class="col-10">
                                                        <input class="form-control" type="text" value="<?php echo $prenom; ?>" name="Prenom">
                                                    </div>
                                                </div>
                                                <?php
                                                if (!empty($erreurs['prenom'])) {
                                                    ?>
                                                    <div class="alert alert-danger alert-dismissable" role="alert">
                                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                        <h4 class="alert-heading">Erreur</h4>
                                                        <p><?php echo GetFlashMessage();?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="form-group row">
                                                    <label class="col-2 col-form-label">Email :</label>
                                                    <div class="col-10">
                                                        <input class="form-control" type="email" value="<?php echo $email; ?>" name="Email">
                                                    </div>
                                                </div>
                                                <?php
                                                if (!empty($erreurs['email'])) {
                                                    ?>
                                                    <div class="alert alert-danger alert-dismissable" role="alert">
                                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                        <h4 class="alert-heading">Erreur</h4>
                                                        <p><?php echo GetFlashMessage(); ?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="form-group row">
                                                    <label class="col-2 col-form-label">Mot de passe :</label>
                                                    <div class="col-10">
                                                        <input class="form-control" type="password" value="" name="Pwd">
                                                    </div>
                                                </div>
                                                <?php
                                                if (!empty($erreurs['password'])) {
                                                    ?>
                                                    <div class="alert alert-danger alert-dismissable" role="alert">
                                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                        <h4 class="alert-heading">Erreur</h4>
                                                        <p><?php echo GetFlashMessage(); ?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <button type="button" class="btn btn-primary" data-dismiss="modal">Annuler</button>
                                                <input type="submit" name="submit" value="Modifier" class="btn btn-danger btn-ok">
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-danger btn-lg" data-href="#confirm-delete?id=<?php echo $_GET['id'];?>" data-toggle="modal" data-target="#confirm-delete">
                               <span class="glyphicon glyphicon-remove" style="width:50px;"></span>
                            </button>
                            <div id="confirm-delete" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Suppression</h4>
                                        </div>
                                        <div class="modal-body">
                                            <p>Voulez-vous vraiment supprimer cet utilisateur ?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-primary" data-dismiss="modal">Non</button>
                                            <a href="delete.php?id=<?php echo $_GET['id'];?>" class="btn btn-danger btn-ok">Oui</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <hr>
                            <!-- Créer une fonction PHP pour récupérer les données de chaque user !-->
                            <h2>Horaires</h2>
                            <table class="table">
                                <tr>
                                    <td></td>
                                    <th>Lundi</th>
                                    <th>Mardi</th>
                                    <th>Mercredi</th>
                                    <th>Jeudi</th>
                                    <th>Vendredi</th>
                                </tr>
                                <tr>
                                    <th>Début matin</th>
                                    <td><?php echo $lundiMatin; ?></td>
                                    <td><?php echo $mardiMatin; ?></td>
                                    <td><?php echo $mercrediMatin; ?></td>
                                    <td><?php echo $jeudiMatin; ?></td>
                                    <td><?php echo $vendrediMatin; ?></td>
                                </tr>
                                <tr>
                                    <th>Début après midi</th>
                                    <td><?php echo $lundiApresMidi; ?></td>
                                    <td><?php echo $mardiApresMidi; ?></td>
                                    <td><?php echo $mercrediApresMidi; ?></td>
                                    <td><?php echo $jeudiApresMidi; ?></td>
                                    <td><?php echo $vendrediApresMidi; ?></td>
                                </tr>
                            </table>
                        </div>
                        <div>
                            <hr>
                            <h2>Horodatage</h2>
                            <table class='table'>
                                <tr>
                                    <th>Entrée</th>
                                    <th>Sortie</th>
                                </tr>
                                <?php
                                    for ($index = 0; $index < count($entree); $index++) {
                                        echo $entree[$index];
                                        if($index < count($sortie)){
                                            echo $sortie[$index];
                                        }
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"
        integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
        <script src="../bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    </body>
</html>